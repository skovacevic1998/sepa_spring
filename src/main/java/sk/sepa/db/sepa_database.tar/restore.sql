--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.4
-- Dumped by pg_dump version 15.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE sepa_database;
--
-- Name: sepa_database; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE sepa_database WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Croatian_Croatia.1250';


ALTER DATABASE sepa_database OWNER TO postgres;

\connect sepa_database

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: sepa_dev; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA sepa_dev;


ALTER SCHEMA sepa_dev OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: banka; Type: TABLE; Schema: sepa_dev; Owner: postgres
--

CREATE TABLE sepa_dev.banka (
    id integer NOT NULL,
    ime_banke text NOT NULL,
    vbdi_banke text NOT NULL,
    sts_banke boolean NOT NULL,
    date date NOT NULL,
    iznos_naknade numeric(10,2) NOT NULL,
    vrsta_naknade integer NOT NULL
);


ALTER TABLE sepa_dev.banka OWNER TO postgres;

--
-- Name: banka_id_seq; Type: SEQUENCE; Schema: sepa_dev; Owner: postgres
--

CREATE SEQUENCE sepa_dev.banka_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE sepa_dev.banka_id_seq OWNER TO postgres;

--
-- Name: banka_id_seq; Type: SEQUENCE OWNED BY; Schema: sepa_dev; Owner: postgres
--

ALTER SEQUENCE sepa_dev.banka_id_seq OWNED BY sepa_dev.banka.id;


--
-- Name: grupa_naloga; Type: TABLE; Schema: sepa_dev; Owner: postgres
--

CREATE TABLE sepa_dev.grupa_naloga (
    id integer NOT NULL,
    id_user integer NOT NULL,
    sts_grupe character varying(40) NOT NULL,
    date character varying(40)
);


ALTER TABLE sepa_dev.grupa_naloga OWNER TO postgres;

--
-- Name: grupa_naloga_id_seq; Type: SEQUENCE; Schema: sepa_dev; Owner: postgres
--

CREATE SEQUENCE sepa_dev.grupa_naloga_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE sepa_dev.grupa_naloga_id_seq OWNER TO postgres;

--
-- Name: grupa_naloga_id_seq; Type: SEQUENCE OWNED BY; Schema: sepa_dev; Owner: postgres
--

ALTER SEQUENCE sepa_dev.grupa_naloga_id_seq OWNED BY sepa_dev.grupa_naloga.id;


--
-- Name: nalog; Type: TABLE; Schema: sepa_dev; Owner: postgres
--

CREATE TABLE sepa_dev.nalog (
    id integer NOT NULL,
    id_grupe_naloga integer NOT NULL,
    id_user integer NOT NULL,
    id_banke integer NOT NULL,
    tip_naloga character varying(40),
    valuta_placanja character varying(3),
    iznos numeric(10,2) NOT NULL,
    ime_plat character varying(40),
    adresa_plat character varying(40),
    mjesto_plat character varying(40),
    ime_prim character varying(40),
    adresa_prim character varying(40),
    mjesto_prim character varying(40),
    sif_opis_plac integer,
    dat_izvrsenja date,
    dat_podnosenja date,
    drzava_plat character varying(2),
    kontrolni_broj_plat character varying(2),
    iban_plat character varying(40),
    model_plat character varying(40),
    pnb_plat character varying(40),
    drzava_prim character varying(2),
    kontrolni_broj_prim character varying(2),
    iban_prim character varying(40),
    model_prim character varying(40),
    pnb_prim character varying(40),
    opis_plac character varying(80),
    br_blagajne integer,
    vr_naknade integer,
    iznos_naknade numeric(10,2),
    sif_namjene character varying(5),
    sts_naloga character varying(40)
);


ALTER TABLE sepa_dev.nalog OWNER TO postgres;

--
-- Name: nalog_id_seq; Type: SEQUENCE; Schema: sepa_dev; Owner: postgres
--

CREATE SEQUENCE sepa_dev.nalog_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE sepa_dev.nalog_id_seq OWNER TO postgres;

--
-- Name: nalog_id_seq; Type: SEQUENCE OWNED BY; Schema: sepa_dev; Owner: postgres
--

ALTER SEQUENCE sepa_dev.nalog_id_seq OWNED BY sepa_dev.nalog.id;


--
-- Name: racun; Type: TABLE; Schema: sepa_dev; Owner: postgres
--

CREATE TABLE sepa_dev.racun (
    id integer NOT NULL,
    drzava_rac character varying(2) NOT NULL,
    kontrolni_broj_rac character varying(2) NOT NULL,
    iban_rac character varying(40) NOT NULL,
    ime_rac character varying(40),
    adresa_rac character varying(80),
    mjesto_rac character varying(40),
    sts_rac character(1) NOT NULL,
    date date NOT NULL,
    vbdi_rac integer NOT NULL,
    id_banke integer NOT NULL
);


ALTER TABLE sepa_dev.racun OWNER TO postgres;

--
-- Name: racun_id_seq; Type: SEQUENCE; Schema: sepa_dev; Owner: postgres
--

CREATE SEQUENCE sepa_dev.racun_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE sepa_dev.racun_id_seq OWNER TO postgres;

--
-- Name: racun_id_seq; Type: SEQUENCE OWNED BY; Schema: sepa_dev; Owner: postgres
--

ALTER SEQUENCE sepa_dev.racun_id_seq OWNED BY sepa_dev.racun.id;


--
-- Name: users; Type: TABLE; Schema: sepa_dev; Owner: postgres
--

CREATE TABLE sepa_dev.users (
    id bigint NOT NULL,
    ime character varying(30),
    prezime character varying(30),
    email character varying(80),
    password character varying(80),
    dob integer,
    lokacija character varying(20),
    username character varying(20),
    roles character varying(50),
    br_blagajne bigint
);


ALTER TABLE sepa_dev.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: sepa_dev; Owner: postgres
--

CREATE SEQUENCE sepa_dev.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE sepa_dev.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: sepa_dev; Owner: postgres
--

ALTER SEQUENCE sepa_dev.users_id_seq OWNED BY sepa_dev.users.id;


--
-- Name: vrsta_namjene; Type: TABLE; Schema: sepa_dev; Owner: postgres
--

CREATE TABLE sepa_dev.vrsta_namjene (
    id integer NOT NULL,
    sif_namjene character varying(10) NOT NULL,
    opis text NOT NULL,
    date date NOT NULL
);


ALTER TABLE sepa_dev.vrsta_namjene OWNER TO postgres;

--
-- Name: vrsta_namjene_id_seq; Type: SEQUENCE; Schema: sepa_dev; Owner: postgres
--

CREATE SEQUENCE sepa_dev.vrsta_namjene_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE sepa_dev.vrsta_namjene_id_seq OWNER TO postgres;

--
-- Name: vrsta_namjene_id_seq; Type: SEQUENCE OWNED BY; Schema: sepa_dev; Owner: postgres
--

ALTER SEQUENCE sepa_dev.vrsta_namjene_id_seq OWNED BY sepa_dev.vrsta_namjene.id;


--
-- Name: vrsta_opisa_placanja; Type: TABLE; Schema: sepa_dev; Owner: postgres
--

CREATE TABLE sepa_dev.vrsta_opisa_placanja (
    id integer NOT NULL,
    sif_opis_plac integer NOT NULL,
    opis text NOT NULL,
    date date NOT NULL
);


ALTER TABLE sepa_dev.vrsta_opisa_placanja OWNER TO postgres;

--
-- Name: vrsta_opisa_placanja_id_seq; Type: SEQUENCE; Schema: sepa_dev; Owner: postgres
--

CREATE SEQUENCE sepa_dev.vrsta_opisa_placanja_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE sepa_dev.vrsta_opisa_placanja_id_seq OWNER TO postgres;

--
-- Name: vrsta_opisa_placanja_id_seq; Type: SEQUENCE OWNED BY; Schema: sepa_dev; Owner: postgres
--

ALTER SEQUENCE sepa_dev.vrsta_opisa_placanja_id_seq OWNED BY sepa_dev.vrsta_opisa_placanja.id;


--
-- Name: banka id; Type: DEFAULT; Schema: sepa_dev; Owner: postgres
--

ALTER TABLE ONLY sepa_dev.banka ALTER COLUMN id SET DEFAULT nextval('sepa_dev.banka_id_seq'::regclass);


--
-- Name: grupa_naloga id; Type: DEFAULT; Schema: sepa_dev; Owner: postgres
--

ALTER TABLE ONLY sepa_dev.grupa_naloga ALTER COLUMN id SET DEFAULT nextval('sepa_dev.grupa_naloga_id_seq'::regclass);


--
-- Name: nalog id; Type: DEFAULT; Schema: sepa_dev; Owner: postgres
--

ALTER TABLE ONLY sepa_dev.nalog ALTER COLUMN id SET DEFAULT nextval('sepa_dev.nalog_id_seq'::regclass);


--
-- Name: racun id; Type: DEFAULT; Schema: sepa_dev; Owner: postgres
--

ALTER TABLE ONLY sepa_dev.racun ALTER COLUMN id SET DEFAULT nextval('sepa_dev.racun_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: sepa_dev; Owner: postgres
--

ALTER TABLE ONLY sepa_dev.users ALTER COLUMN id SET DEFAULT nextval('sepa_dev.users_id_seq'::regclass);


--
-- Name: vrsta_namjene id; Type: DEFAULT; Schema: sepa_dev; Owner: postgres
--

ALTER TABLE ONLY sepa_dev.vrsta_namjene ALTER COLUMN id SET DEFAULT nextval('sepa_dev.vrsta_namjene_id_seq'::regclass);


--
-- Name: vrsta_opisa_placanja id; Type: DEFAULT; Schema: sepa_dev; Owner: postgres
--

ALTER TABLE ONLY sepa_dev.vrsta_opisa_placanja ALTER COLUMN id SET DEFAULT nextval('sepa_dev.vrsta_opisa_placanja_id_seq'::regclass);


--
-- Data for Name: banka; Type: TABLE DATA; Schema: sepa_dev; Owner: postgres
--

\i $$PATH$$/3370.dat

--
-- Data for Name: grupa_naloga; Type: TABLE DATA; Schema: sepa_dev; Owner: postgres
--

\i $$PATH$$/3372.dat

--
-- Data for Name: nalog; Type: TABLE DATA; Schema: sepa_dev; Owner: postgres
--

\i $$PATH$$/3374.dat

--
-- Data for Name: racun; Type: TABLE DATA; Schema: sepa_dev; Owner: postgres
--

\i $$PATH$$/3376.dat

--
-- Data for Name: users; Type: TABLE DATA; Schema: sepa_dev; Owner: postgres
--

\i $$PATH$$/3368.dat

--
-- Data for Name: vrsta_namjene; Type: TABLE DATA; Schema: sepa_dev; Owner: postgres
--

\i $$PATH$$/3378.dat

--
-- Data for Name: vrsta_opisa_placanja; Type: TABLE DATA; Schema: sepa_dev; Owner: postgres
--

\i $$PATH$$/3380.dat

--
-- Name: banka_id_seq; Type: SEQUENCE SET; Schema: sepa_dev; Owner: postgres
--

SELECT pg_catalog.setval('sepa_dev.banka_id_seq', 1, false);


--
-- Name: grupa_naloga_id_seq; Type: SEQUENCE SET; Schema: sepa_dev; Owner: postgres
--

SELECT pg_catalog.setval('sepa_dev.grupa_naloga_id_seq', 23, true);


--
-- Name: nalog_id_seq; Type: SEQUENCE SET; Schema: sepa_dev; Owner: postgres
--

SELECT pg_catalog.setval('sepa_dev.nalog_id_seq', 15, true);


--
-- Name: racun_id_seq; Type: SEQUENCE SET; Schema: sepa_dev; Owner: postgres
--

SELECT pg_catalog.setval('sepa_dev.racun_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: sepa_dev; Owner: postgres
--

SELECT pg_catalog.setval('sepa_dev.users_id_seq', 2, true);


--
-- Name: vrsta_namjene_id_seq; Type: SEQUENCE SET; Schema: sepa_dev; Owner: postgres
--

SELECT pg_catalog.setval('sepa_dev.vrsta_namjene_id_seq', 9, true);


--
-- Name: vrsta_opisa_placanja_id_seq; Type: SEQUENCE SET; Schema: sepa_dev; Owner: postgres
--

SELECT pg_catalog.setval('sepa_dev.vrsta_opisa_placanja_id_seq', 16, true);


--
-- Name: banka banka_pkey; Type: CONSTRAINT; Schema: sepa_dev; Owner: postgres
--

ALTER TABLE ONLY sepa_dev.banka
    ADD CONSTRAINT banka_pkey PRIMARY KEY (id);


--
-- Name: grupa_naloga grupa_naloga_pkey; Type: CONSTRAINT; Schema: sepa_dev; Owner: postgres
--

ALTER TABLE ONLY sepa_dev.grupa_naloga
    ADD CONSTRAINT grupa_naloga_pkey PRIMARY KEY (id);


--
-- Name: nalog nalog_pkey; Type: CONSTRAINT; Schema: sepa_dev; Owner: postgres
--

ALTER TABLE ONLY sepa_dev.nalog
    ADD CONSTRAINT nalog_pkey PRIMARY KEY (id);


--
-- Name: racun racun_pkey; Type: CONSTRAINT; Schema: sepa_dev; Owner: postgres
--

ALTER TABLE ONLY sepa_dev.racun
    ADD CONSTRAINT racun_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: sepa_dev; Owner: postgres
--

ALTER TABLE ONLY sepa_dev.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: vrsta_namjene vrsta_namjene_pkey; Type: CONSTRAINT; Schema: sepa_dev; Owner: postgres
--

ALTER TABLE ONLY sepa_dev.vrsta_namjene
    ADD CONSTRAINT vrsta_namjene_pkey PRIMARY KEY (id);


--
-- Name: vrsta_opisa_placanja vrsta_opisa_placanja_pkey; Type: CONSTRAINT; Schema: sepa_dev; Owner: postgres
--

ALTER TABLE ONLY sepa_dev.vrsta_opisa_placanja
    ADD CONSTRAINT vrsta_opisa_placanja_pkey PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

